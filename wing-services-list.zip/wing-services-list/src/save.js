/**
 * Wing Services List – Save Component
 *
 * This is a server-side rendered (dynamic) block.
 * The save function returns null so WordPress uses render.php for output.
 */
export default function Save() {
	return null;
}
