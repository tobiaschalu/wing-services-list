/**
 * Wing Services List – View Script
 *
 * Lightweight progressive enhancement:
 * Adds a subtle fade-in animation for cards as they enter the viewport.
 * No dependencies required.
 */
( function () {
	if ( ! ( 'IntersectionObserver' in window ) ) return;

	const cards = document.querySelectorAll( '.wing-services-list__card' );
	if ( ! cards.length ) return;

	const observer = new IntersectionObserver(
		( entries ) => {
			entries.forEach( ( entry ) => {
				if ( entry.isIntersecting ) {
					entry.target.classList.add( 'is-visible' );
					observer.unobserve( entry.target );
				}
			} );
		},
		{ threshold: 0.1 }
	);

	cards.forEach( ( card, i ) => {
		card.style.setProperty( '--wing-delay', `${ i * 60 }ms` );
		card.classList.add( 'wing-anim' );
		observer.observe( card );
	} );
} )();
